<!DOCTYPE html>
<html>

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta charset="utf-8">
<title>Furniture Medic |  Furniture Medic in Texas</title>


<meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="author" content="">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/revolution-slider.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">

<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<!-- Responsive -->

<link href="css/responsive.css" rel="stylesheet">

</head>

<body>

<div class="page-wrapper">
      
    <!-- Preloader -->
 <!--    <div class="preloader"></div> -->
    

    <!-- Main Header-->
    <header class="main-header">
        <!-- Header Top -->
        <div class="header-top">
            <div class="auto-container">
                <div class="row clearfix">
                    
                    <!--Top Left-->
                    <div class="top-left pull-left">
                        
                    </div>
                    
                    <!--Top Right-->
                    <div class="top-right pull-right">
                    
                        <!--social-icon-->
                        <div class="social-icon">
                            
                            
                            
                            
                        </div>
                        
                        <ul>
                            <li><span class="fa fa-envelope-o"></span>info@furnituremedic.site</li>
                            <li><span class="fa fa-phone"></span> +1 812-898-0960</li>
                            
                        </ul>
                        
                        
                    </div>
                    
                </div>
                
            </div>
        </div><!-- Header Top End -->
        
        
        <!-- Main Box -->
        <div class="main-box">
            <div class="auto-container">
                <div class="outer-container clearfix">
                    <!--Logo Box-->
                     <div class="pos-rel ">
                        <div class="logo"><a href="index.html" class="col-md-3"><h3 style="text-align: center; margin-left: -20px; margin-top: 7px; background: #cd7204; color: #ffffff; padding: 5px 5px 5px 5px; font-weight: bold;  border-radius: 10px;">Furniture Medic</h3></a></div>
                    </div>
                    
                    <!--Nav Outer-->
                    <div class="nav-outer clearfix">
                        <!-- Main Menu -->
                        <nav class="main-menu">
                            <div class="navbar-header">
                                <!-- Toggle Button -->      
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                </button>
                            </div>
                            
                            <div class="navbar-collapse collapse clearfix">
                                <ul class="navigation clearfix">
                                    <li class="current"><a href="index.html">Home</a></li>
                                   <li><a href="about-us.html">About Us</a></li>
                                    <li class="dropdown"><a href="services.html">Services</a>
                                        <ul>
                                             <li><a href="colorpaintservices.html">Color Paint Services</a></li>
                            <li><a href="constructionservices.html">Construction Services</a></li>
                            <li><a href="woodenfurnitureservices.html">Wooden Furniture Services</a></li>
                            <li><a href="waterproofingservices.html">Water Proofing Services</a></li>
                            <li><a href="thermalinsulationservices.html">Modular Kitchen Services</a></li>
                             <li><a href="interiorservices.html">Interior Services</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <ul>
                                               
                                                
                                                   
                                        </ul>
                                    </li>
                                    
                                    
                                    <li><a href="contact.html">Contact</a></li>
                                    
                                 </ul>
                            </div>
                        </nav><!-- Main Menu End-->
                        
                    </div><!--Nav Outer End-->
                    
                    <!-- Hidden Nav Toggler -->
                    <div class="nav-toggler">
                    <button class="hidden-bar-opener"><span class="icon fa fa-bars"></span></button>
                    </div><!-- / Hidden Nav Toggler -->
                    
                    
                    
                </div>    
            </div>
        </div>
    
    </header>
    <!--End Main Header -->
    
    
    <!-- Hidden Navigation Bar -->
    <section class="hidden-bar right-align">
        
        <div class="hidden-bar-closer">
            <button class="btn"><i class="fa fa-close"></i></button>
        </div>
        
        <!-- Hidden Bar Wrapper -->
        <div class="hidden-bar-wrapper">
        
            <!-- .logo -->
            <div class="logo text-center">
                <div class="logo"><a href="index.html" class="col-md-3"><h1 style="text-align:center;color:red;margin-left:-20px;">Furniture Medic</h1></a></div>        
            </div><!-- /.logo -->
            
            <!-- .Side-menu -->
            <div class="side-menu">
            <!-- .navigation -->
                <ul class="navigation">
                    <li class="current"><a href="index.html">Home</a></li>
                     <li><a href="about-us.html">About Us</a></li>
                   
                    <li class="dropdown"><a href="services.html">Services</a>
                        <ul class="submenu">
                          
                            <li><a href="colorpaintservices.html">Color Paint Services</a></li>
                            <li><a href="constructionservices.html">Construction Services</a></li>
                            <li><a href="woodenfurnitureservices.html">Wooden Furniture Services</a></li>
                            <li><a href="waterproofingservices.html">Water Proofing Services</a></li>
                            <li><a href="thermalinsulationservices.html">Modular Kitchen Services</a></li>
                             <li><a href="interiorservices.html">Interior Services</a></li>
                           
                        </ul>
                    </li>
                    <li class="dropdown">
                        <ul class="submenu">
                              
                                                
                        </ul>
                    </li>
                   
                     
                                    
                                    <li><a href="contact.html">Contact</a></li> 
                   
                </ul>
            </div><!-- /.Side-menu -->
        
          
        
        </div><!-- / Hidden Bar Wrapper -->
    </section>
    <!-- / Hidden Bar -->    
    
    
    <!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/bg-page-title-1.jpg);">
        <div class="auto-container">
            <h1>Blog Single Post</h1>
        </div>
    </section>
    
    <!--Page Info-->
    <section class="page-info">
        <div class="auto-container clearfix">
            <div class="pull-left"><h2>Blog Single Post</h2></div>
            <div class="pull-right">
                <ul class="bread-crumb clearfix">
                    <li><a href="index.html">Home</a></li>
                    
                    <li>Blog Single Post</li>
                </ul>
            </div>
        </div>
    </section>
    
    <!--Sidebar Page-->
    <div class="sidebar-page-container">
        <div class="auto-container">
            <div class="row clearfix">
                
                <!--Content Side-->      
                <div class="content-side col-lg-9 col-md-8 col-sm-12 col-xs-12">
                    
                    <!--News Section-->
                    <section class="news-section large-image-view blog-details no-padd-top no-padd-bottom">
                        
                        <!--News Style One / Boxed-->
                        
                         
                        <div class="news-style-one boxed">
                            <div class="inner-box">
                                <figure class="image-box"><img src="admin/images/blog/wooden-furniture2.jpg" alt=""></figure>
                           		<div class="content">
                                    <h3><a href="#">Wooden Furniture Services</a></h3>
                                    <ul class="post-meta clearfix">
                                        <li><a href="#"><span class="icon fa fa-clock-o"></span> 2020-01-20</a></li>
                                        
                                    </ul>
                                    <div class="text">
                                    	<p>We procure this furniture from trusted vendors and also offer customization of these as per the requirements of the client. Our clients can avail from us an extensive variety of Wooden Flooring which enhances the interior décor of living rooms, bedrooms, kitchens and office rooms. The Wooden Flooring that we offer is highly appreciated for toughness, stain resistance and low maintenance. Available in different variety of thickness, colours finish and polish, this flooring is easy to clean and maintain.</p>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        
                        
                         
                       
                       
                        
                        
            
                    </section>
                
                </div><!--End Content Side-->   
                
                 <!--Sidebar-->      
                <div class="sidebar-side col-lg-3 col-md-4 col-sm-6 col-xs-12">
                    <aside class="sidebar">
                        
                        <!-- Search Form -->
                        <div class="widget search-box sidebar-widget">
                            
                            <form method="post" action="#">
                                <div class="form-group">
                                    <input type="search" name="search-field" value="" placeholder="Search Keyword">
                                    <button type="submit"><span class="icon fa fa-search"></span></button>
                                </div>
                            </form>
                            
                        </div>
                        
                        <!-- Popular Categories -->
                        <div class="widget popular-categories sidebar-widget">
                            <div class="sidebar-title"><h3>Services Categories</h3></div>
                            
                            <ul class="list">

                                <li><a href="colorpaintservices.html">Color Paint Services</a></li>
                            <li><a href="constructionservices.html">Construction Services</a></li>
                            <li><a href="woodenfurnitureservices.html">Wooden Furniture Services</a></li>
                            <li><a href="waterproofingservices.html">Water Proofing Services</a></li>
                            <li><a href="thermalinsulationservices.html">Modular Kitchen Services</a></li>
                             <li><a href="interiorservices.html">Interior Services</a></li>
                          
                            </ul>
                            
                        </div>
                        
                        <!-- Recent Posts -->
                        
                        
                    </aside>
                </div><!--End Sidebar-->  
            </div>
        </div>
    </div>
      
             
     <!--Main Footer-->
    <footer class="main-footer" style="background-image:url(images/background/footer-bg.jpg);">
        <div class="auto-container">
        
            <!--Widgets Section-->
            <div class="widgets-section">
                <div class="row clearfix">
                    <!--Big Column-->
                    <div class="big-column col-md-6 col-sm-12 col-xs-12">
                        <div class="row clearfix">
                            
                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget about-widget">
                                    <div class="footer-logo"><figure><a href="index.html"><h3 style="text-align: center; margin-left: -20px; margin-bottom: 7px; background: #cd7204; color: #ffffff; padding: 5px 5px 5px 5px; font-weight: bold;  border-radius: 10px;">Furniture Medic</h3></a></figure></div>
                                    <div class="widget-content">
                                        <div class="text">
                                            Furniture Medic are an Interior Design Consultancy firm situated in Santa Fe, Texas. Furniture Medic were begun in 2014 by Peter Holland at Santa Fe, Texas.
                                        </div>
                                         <div class="social-icon">
                            
                            
                            
                            
                        </div>
                                    </div>

                                </div>
                            </div>
                            
                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget tags-widget">
                                   <h2>Quick Links</h2>
                                    <ul>
                                           <li><a href="index.html" style="color: #fff;">Home</a></li>
                                            <li><a href="about-us.html" style="color: #fff;">About Us</a></li>
                                            <li><a href="services.html" style="color: #fff;">Services</a></li>
                                             
                                              
                                               <li><a href="contact.html" style="color: #fff;">Contact Us</a></li>
                                        </ul>
                                </div>
                                
                            </div>
                            
                        </div>
                    </div>
                    
                    <!--Big Column-->
                    <div class="big-column col-md-6 col-sm-12 col-xs-12">
                        <div class="row clearfix">
                            
                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget posts-widget">
                                    <h2>Services</h2>
                                    <ul>
                                           <li><a href="colorpaintservices.html" style="color: #fff;">Color Paint Services</a></li>
                            <li><a href="constructionservices.html" style="color: #fff;">Construction Services</a></li>
                            <li><a href="woodenfurnitureservices.html" style="color: #fff;">Wooden Furniture Services</a></li>
                            <li><a href="waterproofingservices.html" style="color: #fff;">Water Proofing Services</a></li>
                            <li><a href="thermalinsulationservices.html" style="color: #fff;">Modular Kitchen Services</a></li>
                             <li><a href="interiorservices.html" style="color: #fff;">Interior Services</a></li>
                                        </ul>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget contact-widget">
                                    <h2>Contact Us</h2>
                                   <ul class="contact-info">
                                            <li><span class="icon fa fa-map-marker"></span>2282 San Bernardo Avenue, Laredo, TX, USA</li>
                                            <li><span class="icon fa fa-phone"></span>+1 812-898-0960</li>
                                            <li><span class="icon fa fa-envelope-o"></span>info@furnituremedic.site</li>
                                        </ul>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                 </div>
             </div>
        
        </div>
        
        <!--Footer Bottom-->
         <div class="footer-bottom">
            <div class="auto-container">
                <div class="clearfix">
                    <div class="pull-left"><div class="copyright">Copyrights &copy; 2021 Furniture Medic | All Rights Reserved </div></div>
                   
                </div>
            </div>
        </div>
    </footer>
    
    
</div>
<!--End pagewrapper-->


<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="fa fa-long-arrow-up"></span></div>


<script src="js/jquery.js"></script> 
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/script.js"></script>
</body>

<!-- /html2/decorators/blog-single.php , Tue, 15 Oct 2019 16:53:00 GMT -->
</html>